package com.zybooks.fitnessapp;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;

public class AddWeightActivity extends Activity {

    public static final String WEIGHT_ID = "weightId";
    public static final String USER_ID = "userId";
    private EditText mFieldWeight;
    private CalendarView mCalendarView;
    private Button mDelete;
    private AppDB mDB;
    private User user;
    private int userId;
    private int position;
    private int weightId;
    public long date;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_weight);

        mFieldWeight = findViewById(R.id.fieldWeight);
        mCalendarView = findViewById(R.id.calendarView);
        mDelete = findViewById(R.id.buttonDelete);

        // We need a listener to record a new date selection
        mCalendarView.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(@NonNull CalendarView view, int year, int month, int dayOfMonth) {
                String newDate = String.valueOf(year) + "/" + String.valueOf(month+1) + "/" + String.valueOf(dayOfMonth);
                try {
                    date = new SimpleDateFormat("yyyy/MM/dd").parse(newDate).getTime();
                } catch (ParseException e) {
                    e.printStackTrace();
                }
            }
        });

        mDB = AppDB.getInstance(this);

        // Get the user ID from the home screen
        Bundle extras = getIntent().getExtras();
        userId = extras.getInt("USER_ID");

        List<User> result = mDB.userDao().getUserById(userId);
        if (result.size() == 0) {
            Toast.makeText(this, R.string.error_noid, Toast.LENGTH_LONG).show();
            return;
        }

        user = result.get(0);

        // Position of logged weights is always 1:1 with sorted database; use this
        //   to retrieve the fields from the DB and set values. -1 means new entry
        position = extras.getInt("POSITION");
        if (position != -1) {
            List<Measurement> weights = mDB.measurementDao().getByUserId(user.getId());
            weightId = weights.get(position).getId();
            date = weights.get(position).getDate();
            mFieldWeight.setText(String.valueOf(weights.get(position).getWeight()));
            mCalendarView.setDate(date);
            mDelete.setVisibility(View.VISIBLE); // only show when updating an entry
        } else {
            date = mCalendarView.getDate();
        }
    }

    // Return, no updates necessary
    public boolean backClicked(View view) {
        setResult(0);
        finish();
        return true;
    }

    // Save our changes
    public boolean saveClicked(View view) {
        // Update based on positional data
        if (position != -1) {
            Measurement measurement = new Measurement(weightId,
                    user.getId(),
                    date,
                    Integer.parseInt(mFieldWeight.getText().toString()));
            mDB.measurementDao().updateMeasurement(measurement);
        } else {
            // Otherwise add a new entry
            Measurement measurement = new Measurement(user.getId(),
                    date,
                    Integer.parseInt(mFieldWeight.getText().toString()));
            mDB.measurementDao().addMeasurement(measurement);
        }
        // Tell the home screen to update
        setResult(1);
        finish();
        return true;
    }

    public boolean deleteClicked(View view) {
        // Remove the DB entry
        if (position != -1) {
            mDB.measurementDao().deleteMeasurement(weightId);
        }
        setResult(1);
        finish();
        return true;
    }
}