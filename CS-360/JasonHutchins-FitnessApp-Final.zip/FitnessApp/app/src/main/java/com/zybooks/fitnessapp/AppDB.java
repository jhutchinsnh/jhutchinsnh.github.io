package com.zybooks.fitnessapp;
import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.room.TypeConverters;

@Database(entities= {User.class, Measurement.class}, version = 1, exportSchema = false)
public abstract class AppDB extends RoomDatabase {
    private static final String DATABASE_NAME="weight_db";
    private static AppDB mAppDb;
    public static synchronized AppDB getInstance(Context context) {
        if (mAppDb == null) {
            mAppDb = Room.databaseBuilder(context.getApplicationContext(), AppDB.class, DATABASE_NAME).allowMainThreadQueries().build();
        }
        return mAppDb;
    }
    public abstract UserDao userDao();
    public abstract MeasurementDao measurementDao();
}
