package com.zybooks.fitnessapp;

import androidx.room.TypeConverter;
import java.util.Calendar;

// Unused TypeConverters; included for posterity
public class DateConverter {

    @TypeConverter
    public static Calendar toCalendar(Long epoch) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(epoch);
        return calendar;
    }

    @TypeConverter
    public static Long fromCalendar(Calendar calendar) {
        return calendar == null ? null : calendar.getTime().getTime();
    }
}
