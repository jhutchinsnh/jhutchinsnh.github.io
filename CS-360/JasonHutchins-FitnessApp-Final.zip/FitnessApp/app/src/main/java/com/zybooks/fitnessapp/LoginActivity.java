package com.zybooks.fitnessapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Database;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;
import java.util.List;

public class LoginActivity extends AppCompatActivity {
    private EditText mUsername;
    private EditText mPassword;
    private AppDB mDB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mUsername = findViewById(R.id.editTextUsername);
        mPassword = findViewById(R.id.editTextPassword);
        mDB = AppDB.getInstance(this);
    }

    public void Login(View view) {
        // Check if there's a user by that name
        List<User> getUser = mDB.userDao().getUserByName(mUsername.getText().toString());
        // No
        if (getUser.size() == 0) {
            Toast.makeText(this, "User not found! Create an account first.", Toast.LENGTH_SHORT).show();
        } else {
            // Check their password
            if (!getUser.get(0).testPassword(mPassword.getText().toString())) {
                Toast.makeText(this, "Password incorrect!", Toast.LENGTH_SHORT).show();
            } else {
                // Send them to the home screen
                Intent intent = new Intent(this, WeightActivity.class);
                intent.putExtra("USER_ID", getUser.get(0).getId());
                startActivity(intent);
            }
        }
    }

    public void NewAccount(View view) {
        // Register the new user
        User user = new User(mUsername.getText().toString(), mPassword.getText().toString());
        mDB.userDao().addUser(user);
        Toast.makeText(this, "User added! Click Login to continue!", Toast.LENGTH_SHORT).show();
    }
}