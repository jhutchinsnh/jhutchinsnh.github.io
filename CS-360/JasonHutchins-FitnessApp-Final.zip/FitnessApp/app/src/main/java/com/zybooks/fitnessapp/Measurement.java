package com.zybooks.fitnessapp;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

@Entity(tableName="measurements")
public class Measurement {

    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "id")
    public int id;

    @ColumnInfo(name = "user_id")
    public int user_id;

    @ColumnInfo(name = "date")
    public long date;

    @ColumnInfo(name = "weight")
    public int weight;

    public Measurement(int id, int user_id, long date, int weight) {
        this.id = id;
        this.user_id = user_id;
        this.date = date;
        this.weight = weight;
    }

    @Ignore
    public Measurement(int user_id, long date, int weight) {
        this.user_id = user_id;
        this.date = date;
        this.weight = weight;
    }

    public int getId() { return this.id; }

    public void setId(int id) { this.id = id; }

    public int getUserId() { return this.user_id; }

    public void setUserId(int user_id) { this.user_id = user_id; }

    public long getDate() {
        return this.date;
    }

    public void setDate(long date) {
        this.date = date;
    }

    public int getWeight() {
        return this.weight;
    }

    public void setWeight(int weight) {
        this.weight = weight;
    }

    // Dates are stored as epoch longs; convenience function for printing readable dates
    public String getFormattedDate() {
        Date date = new Date(this.date);
        DateFormat format = new SimpleDateFormat("MM/dd/yyyy");
        String formatted = format.format(date);
        return formatted;
    }
}
