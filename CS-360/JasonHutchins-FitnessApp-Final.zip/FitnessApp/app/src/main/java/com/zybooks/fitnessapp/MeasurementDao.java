package com.zybooks.fitnessapp;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface MeasurementDao {
    @Query("SELECT * FROM measurements WHERE user_id=:user_id ORDER BY date DESC")
    List<Measurement> getByUserId(int user_id);

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void addMeasurement(Measurement measurement);

    @Update
    void updateMeasurement(Measurement measurement);

    // Delete based on id field instead of matching measurement object
    @Query("DELETE FROM measurements WHERE id=:id")
    void deleteMeasurement(int id);
}
