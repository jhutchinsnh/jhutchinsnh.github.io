package com.zybooks.fitnessapp;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.util.List;

public class SettingsActivity extends AppCompatActivity {

    private EditText fieldGoalWeight;
    private Switch switchEnableSMS, switchProgress, switchNutrition, switchDailyReminders;
    private AppDB mDB;
    private User user;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        fieldGoalWeight = findViewById(R.id.fieldGoalWeight);
        switchEnableSMS = findViewById(R.id.switchEnableSMS);
        switchProgress = findViewById(R.id.switchProgress);
        switchNutrition = findViewById(R.id.switchNutrition);
        switchDailyReminders = findViewById(R.id.switchDailyReminders);
        mDB = AppDB.getInstance(this);

        // Find the user based on the ID
        Bundle extras = getIntent().getExtras();
        int userId = extras.getInt("USER_ID");

        List<User> result = mDB.userDao().getUserById(userId);
        if (result.size() == 0) {
            Toast.makeText(this, R.string.error_noid, Toast.LENGTH_LONG).show();
            return;
        }

        // Set the goal weight field
        user = result.get(0);
        if (user.getGoalWeight() == -1) {
            fieldGoalWeight.setText("0");
        } else {
            fieldGoalWeight.setText(String.valueOf(user.getGoalWeight()));
        }

        // Set the on/off status of the switches
        switchEnableSMS.setChecked(user.getSMS());
        switchDailyReminders.setChecked(user.getSMSReminders());
        switchNutrition.setChecked(user.getSMSNews());
        switchProgress.setChecked(user.getSMSProgress());

        // Check the availability of the switches
        setToggles();
    }

    public void setSMS(View view) {
        // Check if we have app permissions for SMS
        int smsPermission = ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS);
        if (smsPermission == PackageManager.PERMISSION_GRANTED) {
            setToggles();
        } else {
            // Request from user
            ActivityCompat.requestPermissions(this, new String[]{
                    Manifest.permission.SEND_SMS}, 0);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        // If we lack permission, turn the switch back off
        if (requestCode == 0) {
            if (grantResults.length <= 0 || grantResults[0] != PackageManager.PERMISSION_GRANTED) {
                switchEnableSMS.setChecked(false);
            }
            setToggles();
        }
    }

    // If the overarching SMS isn't enabled, grey out the remaining options
    // (but remember their settings in case the user turns SMS back on)
    public void setToggles(View view) {
        if (!switchEnableSMS.isChecked()) {
            switchDailyReminders.setEnabled(false);
            switchNutrition.setEnabled(false);
            switchProgress.setEnabled(false);
        } else {
            switchDailyReminders.setEnabled(true);
            switchNutrition.setEnabled(true);
            switchProgress.setEnabled(true);
        }
    }

    public void setToggles() {
        if (!switchEnableSMS.isChecked()) {
            switchDailyReminders.setEnabled(false);
            switchNutrition.setEnabled(false);
            switchProgress.setEnabled(false);
        } else {
            switchDailyReminders.setEnabled(true);
            switchNutrition.setEnabled(true);
            switchProgress.setEnabled(true);
        }
    }

    // Return to the home screen without changes
    public boolean backClicked(View view) {
        finish();
        return true;
    }

    // Update the user's preferences and goal weight
    public boolean saveClicked(View view) {
        user.setGoalWeight(Integer.parseInt(fieldGoalWeight.getText().toString()));
        user.setSMS(switchEnableSMS.isChecked());
        user.setSMSReminders(switchDailyReminders.isChecked());
        user.setSMSNews(switchNutrition.isChecked());
        user.setSMSProgress(switchProgress.isChecked());

        mDB.userDao().updateUser(user);

        // Let the home page know we should update
        setResult(1);
        finish();
        return true;
    }
}