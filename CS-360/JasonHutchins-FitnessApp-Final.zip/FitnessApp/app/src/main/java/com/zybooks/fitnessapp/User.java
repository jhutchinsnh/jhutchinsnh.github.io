package com.zybooks.fitnessapp;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

@Entity(tableName="user")
public class User {

    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name="id")
    public int id;

    @ColumnInfo(name="username")
    public String username;

    @ColumnInfo(name="password")
    public String password;

    @ColumnInfo(name="weight")
    public int weight;

    @ColumnInfo(name="goalweight")
    public int goalweight;

    @ColumnInfo(name="sms")
    public boolean sms;

    @ColumnInfo(name="reminders")
    public boolean sms_reminders;

    @ColumnInfo(name="news")
    public boolean sms_news;

    @ColumnInfo(name="progress")
    public boolean sms_progress;

    public User(int id, String username, String password) {
        this.id = id;
        this.username = username;
        this.password = password;
        this.weight = -1;
        this.goalweight = -1;
        this.sms = false;
        this.sms_reminders = false;
        this.sms_news = false;
        this.sms_progress = false;
    }

    @Ignore
    public User(String username, String password) {
        this.username = username;
        this.password = password;
        this.weight = -1;
        this.goalweight = -1;
    }

    // Simple password test
    public boolean testPassword(String pass) {
        if (this.password.equals(pass)) {
            return true;
        } else {
            return false;
        }
    }

    public int getWeight() {
        return this.weight;
    }

    public void setWeight(int weight) {
        this.weight = weight;
    }

    public int getGoalWeight() {
        return this.goalweight;
    }

    public void setGoalWeight(int goalweight) {
        this.goalweight = goalweight;
    }

    public int getId() {
        return this.id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return this.username;
    }

    public void setName(String name) {
        this.username = name;
    }

    public String getPass() {
        return this.password;
    }

    public void setPass(String pass) {
        this.password = pass;
    }

    public boolean getSMS() {
        return this.sms;
    }

    public void setSMS(boolean sms) {
        this.sms = sms;
    }

    public boolean getSMSReminders() {
        return this.sms_reminders;
    }

    public void setSMSReminders(boolean reminders) {
        this.sms_reminders = reminders;
    }

    public boolean getSMSNews() {
        return this.sms_news;
    }

    public void setSMSNews(boolean news) {
        this.sms_news = news;
    }

    public boolean getSMSProgress() {
        return this.sms_progress;
    }

    public void setSMSProgress(boolean progress) {
        this.sms_progress = progress;
    }
}
