package com.zybooks.fitnessapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.ListFragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;


import android.content.SharedPreferences;
import android.os.Bundle;

import android.content.Intent;
import android.preference.PreferenceManager;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;
import android.view.ActionMode;
import android.graphics.Color;

public class WeightActivity extends AppCompatActivity {

    private TextView textWelcome;
    private AppDB mDB;
    private User user;
    private WeightAdapter adapter;
    public List<Measurement> log;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weight);

        textWelcome = findViewById(R.id.textWelcome);

        // Get the supplied user ID from the previous activity
        Bundle extras = getIntent().getExtras();
        int userId = extras.getInt("USER_ID");
        mDB = AppDB.getInstance(this);

        // User should always exist at this stage; fall back to the previous activity otherwise
        List<User> result = mDB.userDao().getUserById(userId);
        if (result.size() == 0) {
            Toast.makeText(this, R.string.error_noid, Toast.LENGTH_LONG).show();
            return;
        }
        user = result.get(0);

        // Update the welcome message
        updateWelcomeText();

        // Create the log of weigh-ins
        RecyclerView weightList = (RecyclerView) findViewById(R.id.weightRecycler);
        log = mDB.measurementDao().getByUserId(user.getId());
        adapter = new WeightAdapter(log);
        weightList.setAdapter(adapter);
        weightList.setLayoutManager(new LinearLayoutManager(this));

        // Listener for user clicking the pencil button
        adapter.setOnItemClickListener(new WeightAdapter.ClickListener() {
            @Override
            public void onItemClick(int position, View view) {
                EditWeight(position);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        // Code 1 indicates we updated something; refresh the home screen
        if (resultCode == 1) {
            List<User> result = mDB.userDao().getUserById(user.getId());
            user = result.get(0);
            updateWelcomeText();

            // Should be refactored, but for a simple app, just rebind to an updated log
            RecyclerView weightList = (RecyclerView) findViewById(R.id.weightRecycler);
            log = mDB.measurementDao().getByUserId(user.getId());
            adapter = new WeightAdapter(log);
            weightList.setAdapter(adapter);
            weightList.setLayoutManager(new LinearLayoutManager(this));
        }
    }

    // Display gear icon
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.settings_menu, menu);
        return true;
    }

    // Checking the user's status:
    public void updateWelcomeText() {
        // No goal weight, no measurements
        if (user.getGoalWeight() == -1) {
            String s = getResources().getString(R.string.welcome_new);
            s = s.replace("$name",user.getName());
            textWelcome.setText(s);
        } else {
            List<Measurement> logs = mDB.measurementDao().getByUserId(user.getId());
            // Goal weight set, no measurements
            if (logs.size() == 0) {
                String s = getResources().getString(R.string.welcome_no_entries);
                s = s.replace("$name",user.getName());
                textWelcome.setText(s);
            } else {
                // Goal weight reached; congratulate user
                if (user.getGoalWeight() == logs.get(0).getWeight()) {
                    String s = getResources().getString(R.string.welcome_congrats);
                    s = s.replace("$name", user.getName());
                    textWelcome.setText(s);
                    Toast.makeText(this, R.string.congrats, Toast.LENGTH_LONG).show();
                } else {
                    // Show how far until next goal weight
                    String s = getResources().getString((R.string.welcome_message));
                    s = s.replace("$name", user.getName());

                    int total = Math.abs(user.getGoalWeight() - logs.get(0).getWeight());
                    s = s.replace("$total", String.valueOf(total));

                    s = s.replace("$goal", String.valueOf(user.getGoalWeight()));
                    textWelcome.setText(s);
                }
            }
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Display the options page
        if (item.getItemId() == R.id.settings) {
            Intent intent = new Intent(this,
                    SettingsActivity.class);
            intent.putExtra("USER_ID", user.getId());
            startActivityForResult(intent, 0);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    // Click behavior for the FAB
    public void AddWeight(View view) {
        Intent intent = new Intent(this, AddWeightActivity.class);
        intent.putExtra("USER_ID", user.getId());
        intent.putExtra("POSITION", -1);
        startActivityForResult(intent, 0);
    }

    // Click behavior for the pencil icon
    public void EditWeight(int position) {
        Intent intent = new Intent(this, AddWeightActivity.class);
        intent.putExtra("USER_ID", user.getId());
        intent.putExtra("POSITION", position);
        startActivityForResult(intent, 0);
    }
}