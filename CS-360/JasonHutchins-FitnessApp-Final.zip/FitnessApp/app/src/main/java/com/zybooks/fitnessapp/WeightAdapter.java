package com.zybooks.fitnessapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

// RecyclerView adapter for displaying measurement logs
public class WeightAdapter extends RecyclerView.Adapter<WeightAdapter.ViewHolder> {

    private static ClickListener clickLIstener;

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        public TextView mDate;
        public TextView mWeight;
        public ImageButton mEdit;

        public ViewHolder(View itemView) {
            super(itemView);

            mDate = (TextView) itemView.findViewById(R.id.textDate);
            mWeight = (TextView) itemView.findViewById(R.id.textWeight);
            mEdit = (ImageButton) itemView.findViewById(R.id.buttonEdit);
            // Make only the pencil button clickable
            mEdit.setOnClickListener(this);
        }

        @Override
        public void onClick (View view) {
            clickLIstener.onItemClick(getAdapterPosition(), view);
        }
    }

    public void setOnItemClickListener(ClickListener clickListener) {
        WeightAdapter.clickLIstener = clickListener;
    }

    public interface ClickListener {
        void onItemClick(int position, View view);
    }

    private List<Measurement> mLog;

    public WeightAdapter(List<Measurement> log) {
        mLog = log;
    }

    @Override
    public WeightAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        Context context = parent.getContext();
        LayoutInflater inflater = LayoutInflater.from(context);
        View weightView = inflater.inflate(R.layout.fragment_weigh_record, parent, false);
        ViewHolder viewHolder = new ViewHolder(weightView);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(WeightAdapter.ViewHolder holder, int position) {
        Measurement measurement = mLog.get(position);
        TextView date = holder.mDate;
        date.setText(String.valueOf(measurement.getFormattedDate()));

        TextView weight = holder.mWeight;
        weight.setText(String.valueOf(measurement.getWeight()));
    }

    @Override
    public int getItemCount() {
        return mLog.size();
    }
}
