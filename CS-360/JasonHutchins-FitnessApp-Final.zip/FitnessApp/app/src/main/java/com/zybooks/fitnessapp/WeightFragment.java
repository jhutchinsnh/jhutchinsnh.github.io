package com.zybooks.fitnessapp;

import androidx.fragment.app.Fragment;

public class WeightFragment extends Fragment {
    // empty
}